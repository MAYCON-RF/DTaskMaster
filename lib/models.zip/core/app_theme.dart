/*
  Tema da Aplicação

  Este arquivo centraliza as definições de estilo utilizadas no app, incluindo:
  - Cores padrão (AppColors)
  - Estilos de texto (AppTextStyles)
  - Gradientes (AppGradients)
  - Tema global do Flutter (ThemeData)
*/


// Importações dos pacotes
import 'package:flutter/material.dart';


// Paleta de cores padrão do aplicativo
class AppColors {
  static const background = Color(0xFF121212);
  static const primaryLogin = Color(0xFF3D52E8);
  static const primaryLight = Color(0xFF877FDF);
  static const primaryTitleOnboarding = Color(0xFFFEDC56);
  static const blueGradientStart = Color(0xFF9BE6F3);
  static const blueGradientEnd = Color(0xFF3D52E8);
  static const textLight = Color(0xFFFFFFFF);
  static const textSubtitle = Color(0xFF000000);
  static const borderLight = Color(0xFFD4D3D2);
  static const indicatorInactive = Colors.white30;
  static const boxPassword = Colors.white30;
  static const textDark = Color(0xFF000000);
  static const borderDark = Color(0xFF2C2C2C);
  static const codeDefault = Colors.grey;
  static const codeValid = Colors.green;
  static const codeInvalid = Colors.redAccent;
  static const Color primary = Color(0xFF00995D);
  static const Color success = Color(0xFF4CAF50); // Verde sucesso
  static const Color warning = Color(0xFFFFC107); // Amarelo alerta
  static const Color error = Color(0xFFF44336);   // Vermelho erro
  static const Color surface = Color(0xFF1E1E1E);  // Cartões e blocos
  static const Color textPrimary = Color(0xFFFFFFFF); // Branco
  static const Color textSecondary = Color(0xFFB0B0B0); // Cinza claro static const Color accentBlue = Color(0xFF2196F3); // Azul de destaque
  static const Color disabled = Color(0xFF616161);   // Cinza escuro para itens desativados
}


// Estilos de texto reutilizáveis
class AppTextStyles {
  static const title = TextStyle(
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.bold,
    fontSize: 20,
    color: AppColors.primaryLogin,
  );

  static const social = TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
    fontSize: 16,
    color: AppColors.textDark,
  );

  static const subtitle = TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
    fontSize: 16,
    color: AppColors.textLight,
  );

  static const button = TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
    fontSize: 16,
    color: Colors.white,
  );

  static const link = TextStyle(
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.bold,
    fontSize: 16,
    color: AppColors.primaryLogin,
    decoration: TextDecoration.underline,
  );
}


// Gradiente padrão utilizado em botões
class AppGradients {
  static const button = LinearGradient(
    colors: [AppColors.blueGradientStart, AppColors.blueGradientEnd],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static const highPriority = LinearGradient(
    colors: [Color(0xFFF5272A), Color(0xFFDF9A9B)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const mediumPriority = LinearGradient(
    colors: [Color(0xFFE6E999), Color(0xFFF0DE15)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const lowPriority = LinearGradient(
    colors: [Color(0xFFE7EEBA), Color(0xFFD0EFC6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}


// Tema global aplicado ao aplicativo Flutter
final ThemeData appTheme = ThemeData(
  scaffoldBackgroundColor: AppColors.background,
  textSelectionTheme: TextSelectionThemeData(
    cursorColor: AppColors.blueGradientEnd,
    selectionHandleColor: AppColors.blueGradientEnd,
    selectionColor: AppColors.blueGradientEnd.withOpacity(0.3),
  ),
);
