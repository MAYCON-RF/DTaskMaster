// Importações dos pacotes
import 'package:flutter/material.dart';
import 'package:desafio_task_master/models/onboarding_model.dart';
import 'package:desafio_task_master/theme/app_colors.dart';
import 'package:desafio_task_master/theme/app_text_styles.dart';
import 'package:desafio_task_master/widgets/back_button_widget.dart';
import 'package:desafio_task_master/widgets/gradient_button.dart';
import 'package:desafio_task_master/widgets/page_indicator.dart';
import 'package:desafio_task_master/services/storage_service.dart';


// Página de Onboarding com as telas deslizáveis
class OnboardingPage extends StatefulWidget {
  @override
  _OnboardingPageState createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  // Controlador da página usada no PageView
  final PageController _pageController = PageController();

  // Índice atual da página utilizado para saber em qual tela do onboarding o usuário está para ajudar no page indicador
  int _currentPage = 0;

  // Serviço para salvar se o onboarding foi concluído
  final StorageService _storageService = StorageService();

  // Lista de modelos das telas de onboarding
  final List<OnboardingModel> pages = [
    // Primeira tela - Tela Inicial - onboarding  Tarefas
    OnboardingModel(
      image: 'assets/onboarding_task.png',
      title: 'Organize sua vida com facilidade',
      subtitle:
      'Crie, edite e acompanhe suas tarefas em um só lugar. Mantenha o controle do seu dia de forma simples e intuitiva.',
      color: AppColors.titlePrimary,
    ),

    // Segunda tela - Tela Inicial - onboarding  Foco
    OnboardingModel(
      image: 'assets/onboarding_focus.png',
      title: 'Foque no que realmente importa',
      subtitle:
      'Classifique suas atividades por prioridade e categorias. Gerencie o que é urgente e o que pode esperar, com total clareza.',
      color: AppColors.titlePrimary,
    ),

    // Terceira Tela - Tela Inicial - onboarding  Alertas
    OnboardingModel(
      image: 'assets/onboarding_alert.png',
      title: 'Nunca mais perca um prazo',
      subtitle:
      'Receba alertas e lembretes automáticos para manter suas tarefas em dia. Seu planejamento sempre na palma da mão.',
      color: AppColors.titlePrimary,
    ),

    // Quarta Tela - Tela Inicial - onboarding  Google Calendar
    OnboardingModel(
      image: 'assets/onboarding_calendar.png',
      title: 'Tudo conectado, sem esforço',
      subtitle:
      'Sincronize suas tarefas diretamente com o Google Calendar e visualize seus compromissos em um só lugar.',
      color: AppColors.titlePrimary,
    ),
  ];

  // Função chamada ao pressionar o botão
  void _onNext() {
    if (_currentPage < pages.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _finishOnboarding();
    }
  }

  // Finaliza o onboarding e salva a preferência
  void _finishOnboarding() async {
    await _storageService.setOnboardingSeen();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          body: Center(child: Text('Tela principal aqui')), // Substituir futuramente pela tela real
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: pages.length,
                onPageChanged: (index) {
                  setState(() {
                    _currentPage = index;
                  });
                },
                itemBuilder: (context, index) {
                  final page = pages[index];
                  return Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Botão de voltar reutilizável
                        BackButtonWidget(
                          pageController: _pageController,
                          currentPage: _currentPage,
                        ),

                        const SizedBox(height: 30),

                        // Imagem principal
                        Image.asset(
                          page.image,
                          height: 160,
                        ),

                        const SizedBox(height: 30),

                        // Título alinhado à esquerda usando estilo global
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            page.title,
                            style: AppTextStyles.title,
                            textAlign: TextAlign.left,
                          ),
                        ),

                        const SizedBox(height: 16),

// Subtítulo alinhado à esquerda usando estilo global
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            page.subtitle,
                            style: AppTextStyles.subtitle,
                            textAlign: TextAlign.left,
                          ),
                        ),

                        const SizedBox(height: 48),

// Indicadores de página mais acima
                        PageIndicator(
                          currentIndex: _currentPage,
                          itemCount: pages.length,
                        ),

                        const SizedBox(height: 24),

// Botão alinhado à direita
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            GradientButton(
                              text: _currentPage == pages.length - 1 ? 'Começar!' : 'Próximo',
                              onTap: _onNext,
                            ),
                          ],
                        ),



                        const SizedBox(height: 20),

                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
